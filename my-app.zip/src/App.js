import React, { Component } from "react";
import "./App.css";
import MyComponenta from "./MyComponenta";


class App extends Component {
  render() {
    return (
      <div className="App">
          <MyComponenta status="Mentor" name="Muhtorov Sardor">
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
              Lorem Ipsum is simply 
            </p>
          </MyComponenta>
          <MyComponenta status="Mentor" name="Muhtorov Sardor">
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
              Lorem Ipsum is simply 
            </p>
          </MyComponenta>
          <MyComponenta status="Junior" name="Valiyev Ali">
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
              Lorem Ipsum is simply 
            </p>
          </MyComponenta>
          <MyComponenta status="Mentor" name="Muhtorov Sardor">
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
              Lorem Ipsum is simply 
            </p>
          </MyComponenta>
          <MyComponenta status="Student" name="Eshmanov Eldor">
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
              Lorem Ipsum is simply 
            </p>
          </MyComponenta>
          <MyComponenta status="Junior" name="Valiyev Ali">
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
              Lorem Ipsum is simply
            </p>
          </MyComponenta>
      </div>
    );
  }
}

export default App;

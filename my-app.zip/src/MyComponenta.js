import React, { Component } from "react";
import Container from "./Container";
import "./MyComponenta.css";

class MyComponenta extends Component {
  render() {
    return (
      <div className="card">
        <div className="card-headr">{this.props.status}</div>
        <div className="card-body">{this.props.children}</div>
        <div className="card-footer">{this.props.name}</div>
      </div>
    );
  }
}

export default MyComponenta;


